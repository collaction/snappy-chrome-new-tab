$(function () {
	$.get({
		url: 'https://snappy.collaction.hk/api_get_daily_photo',
		dataType: "JSON",
		success: function (result) {
			var op = result.op;
			$('.year__str').html(op.year.str);
			$('.year__ago').html(op.year.ago);
			$('.info__desc').html(op.desc);
			$('.info__name').html(op.name);
			$('.info__link').attr('href', op.link + '?utm_source=collaction&utm_campaign=chrome_extension&utm_medium=link');

			$('.backdrop')
				.css('background-image', 'url("' + op.image_url + '")')
				.addClass('animated fadeIn');
			$('.footer__info').fadeIn();
		}
	});
});
